-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Фев 12 2019 г., 16:55
-- Версия сервера: 5.5.25
-- Версия PHP: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `database`
--

-- --------------------------------------------------------

--
-- Структура таблицы `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `topic_text` text NOT NULL,
  `date_mk` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Дамп данных таблицы `topics`
--

INSERT INTO `topics` (`id`, `title`, `topic_text`, `date_mk`) VALUES
(55, 'Sabyrov Beksultan', 'Родился 5 марта 1996года', '09.02.2019'),
(56, 'Satybekov Azamat', 'Родился 6 мая 1996года', '10.02.2019'),
(57, 'Haritonov Sergei', 'Родился 25 января 1992 года', '11.02.2019'),
(58, 'Pavlov Andre', 'Родился 2 Февраля 1994 года', '12.02.2019'),
(59, 'Gaibulin Rustam', 'Родился 8 марта 1990 года', '12.02.2019'),
(60, 'Alex Razumavski', 'Родился 6 апреля 1993 года', '12.02.2019');

-- --------------------------------------------------------

--
-- Структура таблицы `topic_comments`
--

CREATE TABLE IF NOT EXISTS `topic_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_text` text NOT NULL,
  `date_mk` varchar(255) NOT NULL,
  `topic_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- Дамп данных таблицы `topic_comments`
--

INSERT INTO `topic_comments` (`id`, `comment_text`, `date_mk`, `topic_id`) VALUES
(45, 'oofofo', '1549979057', 56),
(46, 'comments', '1549979474', 60),
(47, 'Добавление комментария', '1549979517', 59),
(48, 'Add comments', '1549979542', 58),
(49, 'Commentari', '1549979579', 57),
(50, 'Коммент кош', '1549979598', 56),
(51, 'Написать коммент', '1549979633', 55),
(52, 'тест', '1549979704', 57);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
